#include <linux/time32.h>

struct old_timeval32 tv;
